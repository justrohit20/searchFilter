package com.VectorOneNine.Search.Repo;

import java.util.List;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;

import com.VectorOneNine.Search.entity.Data;

public interface dataRepo extends JpaRepository<Data, String>{

	List<Data> findAll(Specification<Data> specification);
	

}
