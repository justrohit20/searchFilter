package com.VectorOneNine.Search.dataService;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.VectorOneNine.Search.entity.Data;

import jakarta.persistence.criteria.CriteriaBuilder;
//import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Predicate;

public class dataService {
public static Specification<Data> getSpec(String state, String postcode){
  return ((root, query, criteriaBuilder) ->{
	
	List<Predicate> predicate= new ArrayList<>();
	
	if(state!=null&& !(state.isEmpty()))
		predicate.add(criteriaBuilder.equal(root.get("state"),state));
	
	if(postcode!=null&& !(postcode.isEmpty()))
		predicate.add(criteriaBuilder.equal(root.get("postcode"),postcode));
	
	return criteriaBuilder.and(predicate.toArray(new Predicate[0]));
});
}
}
