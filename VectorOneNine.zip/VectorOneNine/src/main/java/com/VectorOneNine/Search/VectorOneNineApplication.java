package com.VectorOneNine.Search;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VectorOneNineApplication {

	public static void main(String[] args) {
		SpringApplication.run(VectorOneNineApplication.class, args);
	}

}
