package com.VectorOneNine.Search.controller;
import com.VectorOneNine.Search.Repo.dataRepo;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.VectorOneNine.Search.dataService.dataService;
import com.VectorOneNine.Search.entity.Data;

@RestController
@RequestMapping("/search?*")
public class dataController {
	
	@Autowired
	public dataRepo dataRepo;
	
	public List<Data> list(@RequestParam(value = "state", required=false)String state,
			              @RequestParam( value= "postcode", required=false) String postcode){
		
		Specification<Data> specification= dataService.getSpec(state, postcode);
		return dataRepo. findAll(specification);
				
	}

}
